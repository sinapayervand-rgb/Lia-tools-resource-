Lia Tools needs a compiled shell_template.apk in this folder to build anything.

How to produce it:
  1. Open the companion project /LiaTools-ShellTemplate in Android Studio.
  2. Build > Build Bundle(s)/APK(s) > Build APK(s)  (or `./gradlew assembleRelease`)
  3. Take the output APK (app/build/outputs/apk/release/app-release.apk)
     and copy it into this folder, renamed to:
         shell_template.apk

So the final path is:
  app/src/main/assets/template/shell_template.apk

Full details are in /docs/BUILD_AND_ARCHITECTURE.md at the repo root.
Delete this text file once the real shell_template.apk is in place.
