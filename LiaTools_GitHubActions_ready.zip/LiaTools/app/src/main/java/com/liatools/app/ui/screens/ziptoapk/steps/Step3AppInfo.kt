package com.liatools.app.ui.screens.ziptoapk.steps

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.liatools.app.core.ziptoapk.model.AppBuildConfig

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Step3AppInfo(
    config: AppBuildConfig,
    onAppNameChanged: (String) -> Unit,
    onPackageNameChanged: (String) -> Unit,
    onVersionNameChanged: (String) -> Unit,
    onVersionCodeChanged: (Int) -> Unit,
    onDescriptionChanged: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        OutlinedTextField(
            value = config.appName,
            onValueChange = onAppNameChanged,
            label = { Text("Application Name") },
            placeholder = { Text("My App") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = config.packageName,
            onValueChange = onPackageNameChanged,
            label = { Text("Package Name") },
            placeholder = { Text("com.example.myapp") },
            singleLine = true,
            isError = config.packageNameError() != null,
            supportingText = {
                config.packageNameError()?.let { Text(it) }
            },
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = config.versionName,
                onValueChange = onVersionNameChanged,
                label = { Text("Version Name") },
                placeholder = { Text("1.0") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = config.versionCode.toString(),
                onValueChange = { v -> v.toIntOrNull()?.let(onVersionCodeChanged) },
                label = { Text("Version Code") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
        }

        OutlinedTextField(
            value = config.description,
            onValueChange = onDescriptionChanged,
            label = { Text("App Description") },
            placeholder = { Text("What does your app do?") },
            minLines = 3,
            maxLines = 5,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(24.dp))
    }
}
