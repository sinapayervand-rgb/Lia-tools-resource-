package com.liatools.app.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Lia Tools dark palette.
 * Kept in one place so future tool modules reuse the same brand colors
 * instead of every screen inventing its own greys/accents.
 */

// Backgrounds
val LiaBackground = Color(0xFF0E1013)      // near-black app background
val LiaSurface = Color(0xFF16191D)         // cards / sheets
val LiaSurfaceElevated = Color(0xFF1D2126) // step wizard cards, elevated
val LiaBorder = Color(0xFF2A2E34)

// Brand accent (used for primary actions, progress, active step indicator)
val LiaAccent = Color(0xFF6C5CE7)          // violet
val LiaAccentSecondary = Color(0xFF00D2A8) // teal, used for success states

// Text
val LiaTextPrimary = Color(0xFFF2F3F5)
val LiaTextSecondary = Color(0xFF9AA0A8)
val LiaTextDisabled = Color(0xFF5C6169)

// Status
val LiaError = Color(0xFFFF5C5C)
val LiaWarning = Color(0xFFFFB454)
val LiaSuccess = Color(0xFF00D2A8)
