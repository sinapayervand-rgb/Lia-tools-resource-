package com.liatools.app.core.ziptoapk.sign

import java.security.PrivateKey
import java.security.Signature
import java.security.cert.X509Certificate
import javax.security.auth.x500.X500Principal

/**
 * Builds the META-INF/CERT.RSA file: a PKCS#7 `SignedData` structure wrapping an
 * RSA signature over CERT.SF, plus the signer's certificate so the platform can
 * verify the chain back to a self-consistent root (fine for a self-signed debug
 * cert — the same trust model Android Studio's own debug builds use).
 *
 * This is the "APK Signature Scheme v1" (a.k.a. JAR signing) — the original,
 * simplest APK signing scheme, still honored by every Android version, which is
 * exactly why it's the right target for an on-device signer with no access to
 * apksigner's v2/v3 tooling.
 */
object Pkcs7SignedDataBuilder {

    private const val OID_SIGNED_DATA = "1.2.840.113549.1.7.2"
    private const val OID_DATA = "1.2.840.113549.1.7.1"
    private const val OID_SHA256 = "2.16.840.1.101.3.4.2.1"
    private const val OID_RSA_ENCRYPTION = "1.2.840.113549.1.1.1"

    fun build(contentToSign: ByteArray, privateKey: PrivateKey, certificate: X509Certificate): ByteArray {
        val signature = Signature.getInstance("SHA256withRSA").apply {
            initSign(privateKey)
            update(contentToSign)
        }.sign()

        val digestAlgorithms = Der.set(algorithmIdentifier(OID_SHA256, withNull = true))
        val contentInfoInner = Der.sequence(Der.oid(OID_DATA)) // no [0] content => detached signature
        val certDer = certificate.encoded
        val certificatesSet = Der.tlv(0xA0, certDer) // [0] IMPLICIT SET OF Certificate

        val issuerAndSerial = Der.sequence(
            (certificate.issuerX500Principal as X500Principal).encoded,
            Der.integer(certificate.serialNumber)
        )

        val signerInfo = Der.sequence(
            Der.integer(1), // version
            issuerAndSerial,
            algorithmIdentifier(OID_SHA256, withNull = true), // digestAlgorithm
            algorithmIdentifier(OID_RSA_ENCRYPTION, withNull = true), // digestEncryptionAlgorithm
            Der.octetString(signature) // encryptedDigest
        )
        val signerInfos = Der.set(signerInfo)

        val signedData = Der.sequence(
            Der.integer(1), // version
            digestAlgorithms,
            contentInfoInner,
            certificatesSet,
            signerInfos
        )

        val contentInfo = Der.sequence(
            Der.oid(OID_SIGNED_DATA),
            Der.explicit(0, signedData)
        )

        return contentInfo
    }

    private fun algorithmIdentifier(oid: String, withNull: Boolean): ByteArray =
        if (withNull) Der.sequence(Der.oid(oid), Der.nullValue()) else Der.sequence(Der.oid(oid))
}
