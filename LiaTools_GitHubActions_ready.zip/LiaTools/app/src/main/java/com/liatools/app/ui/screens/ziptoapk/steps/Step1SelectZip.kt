package com.liatools.app.ui.screens.ziptoapk.steps

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.liatools.app.core.ziptoapk.model.AppBuildConfig
import com.liatools.app.ui.components.LiaCard
import com.liatools.app.ui.theme.LiaAccent
import com.liatools.app.ui.theme.LiaSuccess
import com.liatools.app.ui.theme.LiaTextSecondary

@Composable
fun Step1SelectZip(
    config: AppBuildConfig,
    onZipPicked: (android.net.Uri) -> Unit
) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { onZipPicked(it) }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Choose the project ZIP you want turned into an APK.",
            style = MaterialTheme.typography.bodyMedium,
            color = LiaTextSecondary
        )

        LiaCard {
            Text("Supported input", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))
            listOf("HTML / CSS / JS projects", "Web app folders", "APK project ZIP packages").forEach {
                Text("•  $it", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(2.dp))
            }
        }

        Surface(
            onClick = { launcher.launch(arrayOf("application/zip", "application/x-zip-compressed")) },
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (config.isStep1Valid()) Icons.Filled.CheckCircle else Icons.Filled.FolderZip,
                    contentDescription = null,
                    tint = if (config.isStep1Valid()) LiaSuccess else LiaAccent,
                    modifier = Modifier.size(44.dp)
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    text = config.sourceZipName ?: "Tap to select ZIP file",
                    fontWeight = FontWeight.SemiBold
                )
                if (!config.isStep1Valid()) {
                    Spacer(Modifier.height(4.dp))
                    Text(".zip", style = MaterialTheme.typography.bodyMedium, color = LiaTextSecondary)
                }
            }
        }
    }
}
