package com.liatools.app

import android.app.Application

/**
 * App-wide entry point. Kept intentionally thin in v1 — no DI framework yet since
 * there's only one tool. If a second tool needs shared services (e.g. a build-job
 * queue, analytics), wire a lightweight service locator or Hilt here.
 */
class LiaToolsApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
