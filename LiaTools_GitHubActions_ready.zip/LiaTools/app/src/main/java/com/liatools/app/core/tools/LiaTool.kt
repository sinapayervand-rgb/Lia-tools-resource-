package com.liatools.app.core.tools

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Every module inside Lia Tools (ZIP to APK today, more later — e.g. "Image Compressor",
 * "APK Signer", "Icon Generator") implements this contract and registers itself in
 * [ToolRegistry]. The Home screen renders whatever is registered; it never hardcodes
 * a specific tool. This is the seam that lets us add tools without touching Home.
 */
data class LiaTool(
    val id: String,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val enabled: Boolean = true,
    /** Route registered in the NavHost (see LiaNavGraph) for this tool's entry screen. */
    val route: String
)

/**
 * Central place new tools are added. v1 ships with a single entry: ZIP to APK.
 * To add a tool later:
 *   1. Build its screens under ui/screens/<tool>/
 *   2. Build its logic under core/<tool>/
 *   3. Register its route in LiaNavGraph
 *   4. Add one line here
 */
object ToolRegistry {
    fun availableTools(): List<LiaTool> = listOf(
        ZipToApkToolDescriptor.descriptor
    )
}
