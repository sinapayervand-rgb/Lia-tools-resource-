package com.liatools.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.liatools.app.ui.LiaNavGraph
import com.liatools.app.ui.theme.LiaToolsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LiaToolsTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    LiaNavGraph()
                }
            }
        }
    }
}
