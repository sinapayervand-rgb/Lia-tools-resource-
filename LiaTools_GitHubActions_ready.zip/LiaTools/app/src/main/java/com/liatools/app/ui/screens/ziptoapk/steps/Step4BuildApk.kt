package com.liatools.app.ui.screens.ziptoapk.steps

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Rocket
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.liatools.app.core.ziptoapk.ApkExporter
import com.liatools.app.core.ziptoapk.model.BuildStage
import com.liatools.app.ui.components.LiaPrimaryButton
import com.liatools.app.ui.components.LiaSecondaryButton
import com.liatools.app.ui.screens.ziptoapk.WizardUiState
import com.liatools.app.ui.theme.LiaError
import com.liatools.app.ui.theme.LiaSuccess
import com.liatools.app.ui.theme.LiaTextSecondary

@Composable
fun Step4BuildApk(
    uiState: WizardUiState,
    onStartBuild: () -> Unit,
    onRetry: () -> Unit
) {
    val build = uiState.build
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        when {
            build.resultFile != null -> {
                StatusIcon(icon = Icons.Filled.CheckCircle, tint = LiaSuccess)
                Text("APK created successfully", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(build.resultFile.name, color = LiaTextSecondary)

                LiaPrimaryButton(text = "Download APK") {
                    context.startActivity(ApkExporter.shareIntent(context, build.resultFile))
                }
                LiaSecondaryButton(text = "Save APK to Downloads") {
                    ApkExporter.saveToDownloads(context, build.resultFile)
                }
            }

            build.errorMessage != null -> {
                StatusIcon(icon = Icons.Filled.Error, tint = LiaError)
                Text("Build failed", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    build.errorMessage,
                    color = LiaTextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
                LiaPrimaryButton(text = "Try Again", onClick = onRetry)
            }

            build.isBuilding -> {
                BuildProgress(percent = build.percent, stageLabel = build.stage?.label ?: "Preparing")
            }

            else -> {
                StatusIcon(icon = Icons.Filled.Rocket, tint = MaterialTheme.colorScheme.primary)
                Text(
                    "Ready to build your APK",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "This happens fully on your device — no internet connection required.",
                    color = LiaTextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
                LiaPrimaryButton(text = "Build APK", onClick = onStartBuild)
            }
        }
    }
}

@Composable
private fun StatusIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: androidx.compose.ui.graphics.Color) {
    Box(
        modifier = Modifier
            .size(84.dp)
            .clip(CircleShape)
            .background(tint.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(44.dp))
    }
}

@Composable
private fun BuildProgress(percent: Int, stageLabel: String) {
    val animatedProgress by animateFloatAsState(
        targetValue = percent / 100f,
        animationSpec = tween(400),
        label = "build-progress"
    )
    Box(
        modifier = Modifier
            .size(140.dp),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator(
            progress = { animatedProgress },
            modifier = Modifier.fillMaxSize(),
            strokeWidth = 8.dp
        )
        Text("$percent%", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
    Text(stageLabel, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
    Text(
        "Building — please keep the app open",
        color = LiaTextSecondary,
        style = MaterialTheme.typography.bodyMedium
    )
}
