package com.liatools.app.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.liatools.app.ui.screens.ziptoapk.WizardStep
import com.liatools.app.ui.theme.LiaAccent
import com.liatools.app.ui.theme.LiaBorder
import com.liatools.app.ui.theme.LiaSurface
import com.liatools.app.ui.theme.LiaTextSecondary

/** Horizontal 1-2-3-4 progress dots + connecting line shown at the top of the wizard. */
@Composable
fun WizardStepIndicator(current: WizardStep, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        WizardStep.ORDERED.forEachIndexed { index, step ->
            val done = step.index < current.index
            val active = step.index == current.index
            val dotColor = when {
                active -> LiaAccent
                done -> LiaAccent.copy(alpha = 0.55f)
                else -> LiaBorder
            }
            val dotSize by animateDpAsState(if (active) 12.dp else 9.dp, tween(200), label = "dot")

            Box(
                modifier = Modifier
                    .size(dotSize)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            if (index != WizardStep.ORDERED.lastIndex) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(2.dp)
                        .background(if (done) LiaAccent.copy(alpha = 0.55f) else LiaBorder)
                )
            }
        }
    }
}

@Composable
fun LiaPrimaryButton(
    text: String,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = LiaAccent,
            disabledContainerColor = LiaAccent.copy(alpha = 0.35f)
        )
    ) {
        Text(text, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun LiaSecondaryButton(
    text: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = LiaTextSecondary),
        border = androidx.compose.foundation.BorderStroke(1.dp, LiaBorder)
    ) {
        Text(text)
    }
}

/** A simple elevated card container styled consistently across wizard steps. */
@Composable
fun LiaCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(LiaSurface)
            .padding(20.dp),
        content = content
    )
}
