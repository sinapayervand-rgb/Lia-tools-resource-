package com.liatools.app.core.ziptoapk.axml

/**
 * Minimal little-endian reader over a ByteArray. The compiled Android binary XML
 * format (AXML) — used for AndroidManifest.xml inside every APK — is entirely
 * little-endian fixed-width fields, so we don't need anything heavier than this.
 */
class BinaryCursor(private val bytes: ByteArray, var pos: Int = 0) {

    val size: Int get() = bytes.size

    fun u8(): Int {
        val v = bytes[pos].toInt() and 0xFF
        pos += 1
        return v
    }

    fun u16(): Int {
        val v = (bytes[pos].toInt() and 0xFF) or ((bytes[pos + 1].toInt() and 0xFF) shl 8)
        pos += 2
        return v
    }

    fun u32(): Long {
        val b0 = bytes[pos].toLong() and 0xFF
        val b1 = bytes[pos + 1].toLong() and 0xFF
        val b2 = bytes[pos + 2].toLong() and 0xFF
        val b3 = bytes[pos + 3].toLong() and 0xFF
        pos += 4
        return b0 or (b1 shl 8) or (b2 shl 16) or (b3 shl 24)
    }

    fun i32(): Int = u32().toInt()

    fun skip(n: Int) { pos += n }

    companion object {
        /** Writes a u32 (little-endian) directly into [target] at [offset], in place. */
        fun patchU32(target: ByteArray, offset: Int, value: Int) {
            target[offset] = (value and 0xFF).toByte()
            target[offset + 1] = ((value shr 8) and 0xFF).toByte()
            target[offset + 2] = ((value shr 16) and 0xFF).toByte()
            target[offset + 3] = ((value shr 24) and 0xFF).toByte()
        }
    }
}

/** Small append-only little-endian byte writer used to re-emit chunks (e.g. the string pool). */
class BinaryWriter {
    private val buf = ArrayList<Byte>(256)

    val size: Int get() = buf.size

    fun u8(v: Int) { buf.add((v and 0xFF).toByte()) }
    fun u16(v: Int) { u8(v); u8(v shr 8) }
    fun u32(v: Long) { u8((v and 0xFF).toInt()); u8(((v shr 8) and 0xFF).toInt()); u8(((v shr 16) and 0xFF).toInt()); u8(((v shr 24) and 0xFF).toInt()) }
    fun u32(v: Int) = u32(v.toLong() and 0xFFFFFFFFL)
    fun bytes(b: ByteArray) { for (x in b) buf.add(x) }
    fun align4() { while (buf.size % 4 != 0) u8(0) }
    fun toByteArray(): ByteArray = buf.toByteArray()

    /** Overwrite 4 bytes already written, at [offset], with a new u32 value (used to backpatch chunk sizes). */
    fun patchU32(offset: Int, value: Int) {
        buf[offset] = (value and 0xFF).toByte()
        buf[offset + 1] = ((value shr 8) and 0xFF).toByte()
        buf[offset + 2] = ((value shr 16) and 0xFF).toByte()
        buf[offset + 3] = ((value shr 24) and 0xFF).toByte()
    }
}
