package com.liatools.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/**
 * Lia Tools is dark-only by design in v1 (per product spec). We still expose
 * [isSystemInDarkTheme] as a parameter so a future "light mode" toggle tool
 * settings screen can flip it without touching every screen.
 */
private val LiaDarkColorScheme = darkColorScheme(
    primary = LiaAccent,
    onPrimary = LiaTextPrimary,
    secondary = LiaAccentSecondary,
    background = LiaBackground,
    onBackground = LiaTextPrimary,
    surface = LiaSurface,
    onSurface = LiaTextPrimary,
    surfaceVariant = LiaSurfaceElevated,
    onSurfaceVariant = LiaTextSecondary,
    error = LiaError,
    outline = LiaBorder
)

@Composable
fun LiaToolsTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = LiaDarkColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = LiaTypography,
        content = content
    )
}
