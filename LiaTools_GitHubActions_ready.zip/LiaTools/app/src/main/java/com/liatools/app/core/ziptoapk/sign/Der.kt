package com.liatools.app.core.ziptoapk.sign

import java.io.ByteArrayOutputStream
import java.math.BigInteger

/**
 * A tiny ASN.1 DER encoder covering exactly the constructs needed to build a
 * PKCS#7 SignedData block (see [Pkcs7SignedDataBuilder]). Android has no public
 * API for building this on-device (that's normally jarsigner's job on a
 * developer's desktop), so we encode it by hand. Each function mirrors one
 * ASN.1 production; nothing here is APK-specific.
 */
object Der {
    fun length(len: Int): ByteArray {
        if (len < 0x80) return byteArrayOf(len.toByte())
        val bytes = ArrayList<Byte>()
        var v = len
        while (v > 0) { bytes.add(0, (v and 0xFF).toByte()); v = v ushr 8 }
        return byteArrayOf((0x80 or bytes.size).toByte()) + bytes.toByteArray()
    }

    fun tlv(tag: Int, content: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(tag)
        out.write(length(content.size))
        out.write(content)
        return out.toByteArray()
    }

    fun sequence(vararg parts: ByteArray): ByteArray = tlv(0x30, parts.concat())
    fun sequence(parts: List<ByteArray>): ByteArray = tlv(0x30, parts.concat())
    fun set(vararg parts: ByteArray): ByteArray = tlv(0x31, parts.concat())
    fun set(parts: List<ByteArray>): ByteArray = tlv(0x31, parts.concat())

    /** Context-specific constructed tag, e.g. [0] EXPLICIT — used for ContentInfo's optional content. */
    fun explicit(tagNumber: Int, content: ByteArray): ByteArray = tlv(0xA0 or tagNumber, content)

    fun oid(dotted: String): ByteArray {
        val parts = dotted.split(".").map { it.toInt() }
        val out = ByteArrayOutputStream()
        val first = parts[0] * 40 + parts[1]
        out.write(first)
        for (i in 2 until parts.size) {
            var v = parts[i]
            if (v == 0) { out.write(0); continue }
            val chunk = ArrayList<Int>()
            while (v > 0) { chunk.add(0, v and 0x7F); v = v ushr 7 }
            for (j in 0 until chunk.size - 1) out.write(chunk[j] or 0x80)
            out.write(chunk.last())
        }
        return tlv(0x06, out.toByteArray())
    }

    fun nullValue(): ByteArray = byteArrayOf(0x05, 0x00)

    fun integer(value: Int): ByteArray = integer(BigInteger.valueOf(value.toLong()))
    fun integer(value: BigInteger): ByteArray = tlv(0x02, value.toByteArray())

    fun octetString(bytes: ByteArray): ByteArray = tlv(0x04, bytes)

    /** Raw pre-encoded DER bytes passed straight through unwrapped (e.g. a cert we already have as DER). */
    fun raw(bytes: ByteArray): ByteArray = bytes

    private fun Array<out ByteArray>.concat(): ByteArray {
        val out = ByteArrayOutputStream()
        for (p in this) out.write(p)
        return out.toByteArray()
    }
    private fun List<ByteArray>.concat(): ByteArray {
        val out = ByteArrayOutputStream()
        for (p in this) out.write(p)
        return out.toByteArray()
    }
}
