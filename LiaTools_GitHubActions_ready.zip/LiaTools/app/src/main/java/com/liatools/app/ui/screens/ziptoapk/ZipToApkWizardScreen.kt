package com.liatools.app.ui.screens.ziptoapk

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.liatools.app.ui.components.LiaPrimaryButton
import com.liatools.app.ui.components.WizardStepIndicator
import com.liatools.app.ui.screens.ziptoapk.steps.Step1SelectZip
import com.liatools.app.ui.screens.ziptoapk.steps.Step2SelectIcon
import com.liatools.app.ui.screens.ziptoapk.steps.Step3AppInfo
import com.liatools.app.ui.screens.ziptoapk.steps.Step4BuildApk

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZipToApkWizardScreen(
    onBack: () -> Unit,
    viewModel: ZipToApkViewModel = viewModel()
) {
    val uiState by viewModel.state.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(uiState.currentStep.title) },
                navigationIcon = {
                    IconButton(onClick = { if (!viewModel.goBack()) onBack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            // Step 4 (Build) drives its own primary action (Build / Download), so no shared nav bar there.
            if (uiState.currentStep != WizardStep.BUILD) {
                WizardBottomBar(
                    canProceed = viewModel.canProceedFromCurrentStep(),
                    isLastBeforeBuild = uiState.currentStep == WizardStep.APP_INFO,
                    onNext = { viewModel.goNext() }
                )
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            WizardStepIndicator(current = uiState.currentStep)

            AnimatedContent(
                targetState = uiState.currentStep,
                transitionSpec = {
                    val forward = targetState.index >= initialState.index
                    (slideInHorizontally(tween(240)) { w -> if (forward) w else -w } + fadeIn(tween(240)))
                        .togetherWith(slideOutHorizontally(tween(240)) { w -> if (forward) -w else w } + fadeOut(tween(240)))
                },
                label = "wizard-step"
            ) { step ->
                Box(modifier = Modifier.weight(1f, fill = false)) {
                    when (step) {
                        WizardStep.SELECT_ZIP -> Step1SelectZip(
                            config = uiState.config,
                            onZipPicked = viewModel::onZipSelected
                        )
                        WizardStep.SELECT_ICON -> Step2SelectIcon(
                            config = uiState.config,
                            onIconPicked = viewModel::onIconSelected
                        )
                        WizardStep.APP_INFO -> Step3AppInfo(
                            config = uiState.config,
                            onAppNameChanged = viewModel::onAppNameChanged,
                            onPackageNameChanged = viewModel::onPackageNameChanged,
                            onVersionNameChanged = viewModel::onVersionNameChanged,
                            onVersionCodeChanged = viewModel::onVersionCodeChanged,
                            onDescriptionChanged = viewModel::onDescriptionChanged
                        )
                        WizardStep.BUILD -> Step4BuildApk(
                            uiState = uiState,
                            onStartBuild = viewModel::startBuild,
                            onRetry = viewModel::retryBuild
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun WizardBottomBar(canProceed: Boolean, isLastBeforeBuild: Boolean, onNext: () -> Unit) {
    Row(modifier = Modifier.padding(20.dp)) {
        LiaPrimaryButton(
            text = if (isLastBeforeBuild) "Continue to Build" else "Next",
            enabled = canProceed,
            onClick = onNext
        )
    }
}
