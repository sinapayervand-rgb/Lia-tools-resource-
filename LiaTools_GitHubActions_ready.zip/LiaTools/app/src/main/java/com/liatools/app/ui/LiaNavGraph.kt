package com.liatools.app.ui

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideIntoContainer
import androidx.compose.animation.slideOutOfContainer
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.liatools.app.core.tools.ZipToApkRoutes
import com.liatools.app.ui.screens.home.HomeScreen
import com.liatools.app.ui.screens.ziptoapk.ZipToApkWizardScreen

private object LiaRoutes {
    const val HOME = "home"
}

/** Shared, smooth slide+fade transition for every screen change in the app. */
private const val ANIM_DURATION_MS = 260

@Composable
fun LiaNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(
        navController = navController,
        startDestination = LiaRoutes.HOME
    ) {
        composable(
            route = LiaRoutes.HOME,
            exitTransition = { fadeOut(tween(ANIM_DURATION_MS)) },
            popEnterTransition = { fadeIn(tween(ANIM_DURATION_MS)) }
        ) {
            HomeScreen(
                onToolSelected = { tool -> navController.navigate(tool.route) }
            )
        }

        composable(
            route = ZipToApkRoutes.WIZARD,
            enterTransition = {
                slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Left, tween(ANIM_DURATION_MS)) +
                    fadeIn(tween(ANIM_DURATION_MS))
            },
            exitTransition = {
                slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Left, tween(ANIM_DURATION_MS)) +
                    fadeOut(tween(ANIM_DURATION_MS))
            },
            popEnterTransition = { fadeIn(tween(ANIM_DURATION_MS)) },
            popExitTransition = {
                slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Right, tween(ANIM_DURATION_MS)) +
                    fadeOut(tween(ANIM_DURATION_MS))
            }
        ) {
            ZipToApkWizardScreen(onBack = { navController.popBackStack() })
        }
    }
}
