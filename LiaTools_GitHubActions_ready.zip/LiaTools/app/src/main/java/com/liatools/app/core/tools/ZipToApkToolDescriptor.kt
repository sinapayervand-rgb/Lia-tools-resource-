package com.liatools.app.core.tools

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inventory2

/** Route constants for the ZIP to APK wizard, shared between nav graph and Home. */
object ZipToApkRoutes {
    const val WIZARD = "tool/zip_to_apk/wizard"
}

object ZipToApkToolDescriptor {
    val descriptor = LiaTool(
        id = "zip_to_apk",
        title = "ZIP to APK",
        description = "Turn an HTML/CSS/JS or web app ZIP into an installable Android APK.",
        icon = Icons.Filled.Inventory2,
        route = ZipToApkRoutes.WIZARD
    )
}
