package com.liatools.app.core.ziptoapk.axml

/**
 * Decodes the RES_STRING_POOL_TYPE chunk that always sits first inside a compiled
 * AndroidManifest.xml, and can re-encode a (possibly extended) list of strings back
 * into a fresh chunk.
 *
 * Design choice: we always *decode* whatever encoding the template used (UTF-8 or
 * UTF-16, per the pool's flags) but always *re-encode* as plain UTF-16, since that
 * keeps the writer simple and is valid on every Android version. We never need to
 * touch style (spannable) data because AndroidManifest.xml never contains styled
 * strings — if a template ever did, [decode] throws rather than silently corrupting it.
 */
object AxmlStringPool {

    data class Decoded(
        val strings: MutableList<String>,
        /** Absolute byte offset (in the original file) where this chunk starts. */
        val chunkStartOffset: Int,
        /** Absolute byte offset where the chunk ends (start of the next chunk). */
        val chunkEndOffset: Int
    )

    fun decode(bytes: ByteArray, chunkStart: Int): Decoded {
        val c = BinaryCursor(bytes, chunkStart)
        val type = c.u16()
        require(type == AxmlConstants.RES_STRING_POOL_TYPE) { "Expected string pool chunk, got 0x${type.toString(16)}" }
        val headerSize = c.u16()
        val chunkSize = c.u32().toInt()
        val stringCount = c.u32().toInt()
        val styleCount = c.u32().toInt()
        val flags = c.u32().toInt()
        val stringsStart = c.u32().toInt()
        @Suppress("UNUSED_VARIABLE")
        val stylesStart = c.u32().toInt()

        require(styleCount == 0) { "Styled strings in AndroidManifest.xml are not supported by this simplified patcher." }

        val isUtf8 = (flags and AxmlConstants.STRING_POOL_UTF8_FLAG) != 0

        val stringOffsets = IntArray(stringCount)
        for (i in 0 until stringCount) stringOffsets[i] = c.u32().toInt()

        val dataBase = chunkStart + stringsStart
        val out = ArrayList<String>(stringCount)
        for (i in 0 until stringCount) {
            val at = dataBase + stringOffsets[i]
            out.add(if (isUtf8) readUtf8String(bytes, at) else readUtf16String(bytes, at))
        }

        return Decoded(out, chunkStart, chunkStart + chunkSize).also {
            check(headerSize == 28) { "Unexpected string pool header size: $headerSize" }
        }
    }

    private fun readUtf16String(bytes: ByteArray, at: Int): String {
        var p = at
        var len = (bytes[p].toInt() and 0xFF) or ((bytes[p + 1].toInt() and 0xFF) shl 8)
        p += 2
        if (len and 0x8000 != 0) {
            val lo = (bytes[p].toInt() and 0xFF) or ((bytes[p + 1].toInt() and 0xFF) shl 8)
            p += 2
            len = ((len and 0x7FFF) shl 16) or lo
        }
        val sb = StringBuilder(len)
        for (i in 0 until len) {
            val ch = (bytes[p].toInt() and 0xFF) or ((bytes[p + 1].toInt() and 0xFF) shl 8)
            sb.append(ch.toChar())
            p += 2
        }
        return sb.toString()
    }

    private fun readUtf8Len(bytes: ByteArray, pos: IntArray): Int {
        var p = pos[0]
        var v = bytes[p].toInt() and 0xFF
        p += 1
        if (v and 0x80 != 0) {
            val v2 = bytes[p].toInt() and 0xFF
            p += 1
            v = ((v and 0x7F) shl 8) or v2
        }
        pos[0] = p
        return v
    }

    private fun readUtf8String(bytes: ByteArray, at: Int): String {
        val pos = intArrayOf(at)
        readUtf8Len(bytes, pos) // utf16 length (char count) - unused, byte length below is authoritative
        val byteLen = readUtf8Len(bytes, pos)
        val s = String(bytes, pos[0], byteLen, Charsets.UTF_8)
        return s
    }

    /**
     * Re-encodes [strings] as a brand new RES_STRING_POOL_TYPE chunk, UTF-16, no styles.
     * Returns the full chunk bytes (header included), ready to splice into the file.
     */
    fun encodeUtf16(strings: List<String>): ByteArray {
        val w = BinaryWriter()
        w.u16(AxmlConstants.RES_STRING_POOL_TYPE)
        w.u16(28) // headerSize
        val sizePatchOffset = w.size
        w.u32(0) // chunkSize placeholder, patched below
        w.u32(strings.size) // stringCount
        w.u32(0) // styleCount
        w.u32(0) // flags: no UTF8 flag => UTF-16, not sorted
        val stringsStartPatchOffset = w.size
        w.u32(0) // stringsStart placeholder
        w.u32(0) // stylesStart (no styles)

        // offsets table placeholder — we'll compute after encoding string data
        val offsetTableStart = w.size
        for (i in strings.indices) w.u32(0)

        val stringsStart = w.size
        w.patchU32(stringsStartPatchOffset, stringsStart)

        val offsets = IntArray(strings.size)
        for ((i, s) in strings.withIndex()) {
            offsets[i] = w.size - stringsStart
            val len = s.length
            if (len <= 0x7FFF) {
                w.u16(len)
            } else {
                w.u16(0x8000 or (len ushr 16))
                w.u16(len and 0xFFFF)
            }
            for (ch in s) w.u16(ch.code)
            w.u16(0) // NUL terminator
        }
        w.align4()

        for ((i, off) in offsets.withIndex()) {
            w.patchU32(offsetTableStart + i * 4, off)
        }

        w.patchU32(sizePatchOffset, w.size)
        return w.toByteArray()
    }
}
