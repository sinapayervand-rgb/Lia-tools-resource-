package com.liatools.app.core.ziptoapk

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.ByteArrayOutputStream

/**
 * Turns whatever image the user picked in Step 2 (PNG/JPG, any resolution) into
 * the square PNG bytes needed for each mipmap density bucket the shell template
 * ships (see ApkBuilder.ICON_ENTRIES). We don't attempt adaptive-icon layers in
 * v1 — a single square PNG per density is what every Android version supports.
 */
class IconProcessor(private val context: Context) {

    class InvalidIconException(message: String) : Exception(message)

    /** density name -> target pixel size, matching res/mipmap-* buckets in the shell template. */
    val densityTargets = linkedMapOf(
        "mipmap-mdpi" to 48,
        "mipmap-hdpi" to 72,
        "mipmap-xhdpi" to 96,
        "mipmap-xxhdpi" to 144,
        "mipmap-xxxhdpi" to 192
    )

    fun decode(uri: Uri): Bitmap {
        val input = context.contentResolver.openInputStream(uri)
            ?: throw InvalidIconException("Couldn't open the selected image.")
        val bitmap = input.use { BitmapFactory.decodeStream(it) }
            ?: throw InvalidIconException("The selected file isn't a readable PNG or JPG image.")
        return bitmap
    }

    /**
     * Renders [source] at every required density, keyed by density bucket name
     * ("mipmap-mdpi", "mipmap-hdpi", ...) rather than a full archive path — the
     * exact entry name for a given density inside a *compiled* APK can vary
     * (aapt2 sometimes appends a version qualifier like "-v4"), so [ApkBuilder]
     * matches entries by density bucket via regex instead of assuming a fixed path.
     */
    fun renderAllDensities(source: Bitmap): Map<String, ByteArray> {
        val squared = toSquare(source)
        val out = LinkedHashMap<String, ByteArray>()
        for ((density, px) in densityTargets) {
            val scaled = Bitmap.createScaledBitmap(squared, px, px, true)
            val bos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.PNG, 100, bos)
            out[density] = bos.toByteArray()
            if (scaled != squared) scaled.recycle()
        }
        if (squared != source) squared.recycle()
        return out
    }

    private fun toSquare(bitmap: Bitmap): Bitmap {
        if (bitmap.width == bitmap.height) return bitmap
        val side = minOf(bitmap.width, bitmap.height)
        val x = (bitmap.width - side) / 2
        val y = (bitmap.height - side) / 2
        return Bitmap.createBitmap(bitmap, x, y, side, side)
    }
}
