package com.liatools.app.ui.screens.home

import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.liatools.app.core.tools.LiaTool
import com.liatools.app.core.tools.ToolRegistry
import com.liatools.app.ui.theme.LiaAccent
import com.liatools.app.ui.theme.LiaBorder
import com.liatools.app.ui.theme.LiaSurface
import com.liatools.app.ui.theme.LiaSurfaceElevated
import com.liatools.app.ui.theme.LiaTextSecondary
import kotlinx.coroutines.launch

/**
 * The first screen the user sees. Deliberately dumb: it just renders whatever
 * [ToolRegistry] exposes. Adding a second tool later means this file changes
 * zero lines.
 */
@Composable
fun HomeScreen(onToolSelected: (LiaTool) -> Unit) {
    val tools = remember { ToolRegistry.availableTools() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(LiaSurfaceElevated, MaterialTheme.colorScheme.background)
                )
            )
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(Modifier.height(56.dp))

            Column(modifier = Modifier.padding(horizontal = 24.dp)) {
                Text(
                    text = "Lia Tools",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Available Tool",
                    style = MaterialTheme.typography.bodyMedium,
                    color = LiaTextSecondary
                )
            }

            Spacer(Modifier.height(24.dp))

            LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(tools) { tool ->
                    ToolCard(tool = tool, onClick = { onToolSelected(tool) })
                }

                item {
                    ComingSoonCard()
                }
            }
        }
    }
}

@Composable
private fun ToolCard(tool: LiaTool, onClick: () -> Unit) {
    val scale = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(LiaSurface)
            .clickable {
                scope.launch {
                    scale.animateTo(0.97f, tween(80))
                    scale.animateTo(1f, tween(120))
                }
                onClick()
            }
            .padding(20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(LiaAccent.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = tool.icon,
                contentDescription = tool.title,
                tint = LiaAccent
            )
        }

        Spacer(Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(text = "📦 " + tool.title, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text(
                text = tool.description,
                style = MaterialTheme.typography.bodyMedium,
                color = LiaTextSecondary,
                maxLines = 2
            )
        }

        Icon(
            imageVector = Icons.Filled.ChevronRight,
            contentDescription = null,
            tint = LiaTextSecondary
        )
    }
}

@Composable
private fun ComingSoonCard() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .padding(20.dp)
    ) {
        Text(
            text = "More tools are on the way",
            style = MaterialTheme.typography.labelLarge,
            color = LiaTextSecondary
        )
    }
}
