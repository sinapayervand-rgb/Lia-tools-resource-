package com.liatools.app.core.ziptoapk.axml

/**
 * Patches the fields Lia Tools actually needs to change inside a *compiled*
 * AndroidManifest.xml, without a full aapt2 recompile:
 *   - <manifest package="...">
 *   - <manifest android:versionCode="...">
 *   - <manifest android:versionName="...">
 *   - <application android:label="..."> (only when authored as a literal string,
 *     which is how the Lia Tools shell template is built — see /shell-template README)
 *
 * How it works: string-typed attribute values are just indices into the file's
 * string pool. We never need to move or resize any existing element/attribute
 * struct — we simply *append* new strings to the pool and overwrite the 4-byte
 * index fields that point at them, in place. The only chunk that changes size is
 * the string pool itself (which we regenerate wholesale), so everything after it
 * shifts by a constant delta and the outer XML chunk's total-size field is fixed
 * up at the very end. See AxmlStringPool for the encode/decode details.
 */
object AxmlManifestPatcher {

    class UnsupportedManifestException(message: String) : Exception(message)

    data class PatchRequest(
        val newPackageName: String,
        val newVersionName: String,
        val newVersionCode: Int,
        /** Null = leave the application label untouched. */
        val newAppLabel: String? = null
    )

    private data class AttrLoc(val rawValueOffset: Int, val dataOffset: Int, val isString: Boolean)

    fun patch(original: ByteArray, request: PatchRequest): ByteArray {
        val outer = BinaryCursor(original, 0)
        val outerType = outer.u16()
        if (outerType != AxmlConstants.RES_XML_TYPE) {
            throw UnsupportedManifestException("Not a compiled binary AndroidManifest.xml (unexpected root chunk 0x${outerType.toString(16)}).")
        }
        outer.u16() // outer headerSize (8)
        outer.u32() // outer total size (unused here, recomputed at the end)

        val pool = AxmlStringPool.decode(original, chunkStart = 8)
        val strings = pool.strings

        var packageAttr: AttrLoc? = null
        var versionCodeAttr: AttrLoc? = null
        var versionNameAttr: AttrLoc? = null
        var labelAttr: AttrLoc? = null

        var pos = pool.chunkEndOffset
        val fileEnd = original.size

        while (pos < fileEnd - 8) {
            val c = BinaryCursor(original, pos)
            val type = c.u16()
            val headerSize = c.u16()
            val size = c.u32().toInt()
            if (size <= 0 || pos + size > fileEnd) break // defensive: malformed/truncated, stop scanning

            when (type) {
                AxmlConstants.RES_XML_START_ELEMENT_TYPE -> {
                    val attrExtStart = pos + headerSize
                    val ac = BinaryCursor(original, attrExtStart)
                    val nsIdx = ac.i32()
                    val nameIdx = ac.i32()
                    val attributeStart = ac.u16()
                    val attributeSize = ac.u16()
                    val attributeCount = ac.u16()
                    // idIndex/classIndex/styleIndex not needed
                    val elementName = strAt(strings, nameIdx)
                    @Suppress("UNUSED_VARIABLE") val elementNs = nsIdx

                    val attributesBase = attrExtStart + attributeStart
                    for (i in 0 until attributeCount) {
                        val attrOff = attributesBase + i * attributeSize
                        val a = BinaryCursor(original, attrOff)
                        val attrNsIdx = a.i32()
                        val attrNameIdx = a.i32()
                        val rawValueOff = attrOff + 8
                        val dataTypeOff = attrOff + 12 + 3 // size(2)+res0(1) then dataType(1)
                        val dataOff = attrOff + 16
                        val dataType = original[dataTypeOff].toInt() and 0xFF

                        val attrNs = if (attrNsIdx >= 0) strAt(strings, attrNsIdx) else null
                        val attrName = strAt(strings, attrNameIdx)

                        when (elementName) {
                            "manifest" -> when {
                                attrNs == null && attrName == "package" ->
                                    packageAttr = AttrLoc(rawValueOff, dataOff, isString = true)
                                attrNs == AxmlConstants.ANDROID_NS && attrName == "versionCode" ->
                                    versionCodeAttr = AttrLoc(rawValueOff, dataOff, isString = false)
                                attrNs == AxmlConstants.ANDROID_NS && attrName == "versionName" ->
                                    versionNameAttr = AttrLoc(rawValueOff, dataOff, isString = true)
                            }
                            "application" -> {
                                if (attrNs == AxmlConstants.ANDROID_NS && attrName == "label" &&
                                    dataType == AxmlConstants.TYPE_STRING
                                ) {
                                    labelAttr = AttrLoc(rawValueOff, dataOff, isString = true)
                                }
                            }
                        }
                    }
                }
                else -> { /* namespace / end-element / cdata / resource-map: nothing to patch, just skip */ }
            }
            pos += size
        }

        if (packageAttr == null) {
            throw UnsupportedManifestException(
                "Couldn't find <manifest package=\"...\"> in the template's AndroidManifest.xml — is this a valid Lia Tools shell template?"
            )
        }

        // Append the new string values we need; existing indices are untouched so
        // nothing else in the file needs to change.
        val newStrings = ArrayList(strings)
        val packageIdx = newStrings.size.also { newStrings.add(request.newPackageName) }
        val versionNameIdx = newStrings.size.also { newStrings.add(request.newVersionName) }
        val labelIdx = if (request.newAppLabel != null) newStrings.size.also { newStrings.add(request.newAppLabel) } else -1

        val newPoolBytes = AxmlStringPool.encodeUtf16(newStrings)
        val tail = original.copyOfRange(pool.chunkEndOffset, original.size)
        val tailBaseOffset = pool.chunkEndOffset

        fun patchStringAttr(loc: AttrLoc?, newIndex: Int) {
            if (loc == null) return
            BinaryCursor.patchU32(tail, loc.rawValueOffset - tailBaseOffset, newIndex)
            BinaryCursor.patchU32(tail, loc.dataOffset - tailBaseOffset, newIndex)
        }

        patchStringAttr(packageAttr, packageIdx)
        patchStringAttr(versionNameAttr, versionNameIdx)
        if (labelIdx >= 0) patchStringAttr(labelAttr, labelIdx)

        versionCodeAttr?.let { loc ->
            BinaryCursor.patchU32(tail, loc.dataOffset - tailBaseOffset, request.newVersionCode)
        }

        // Assemble: outer header (8 bytes, size fixed up below) + new string pool + patched tail
        val out = ByteArray(8 + newPoolBytes.size + tail.size)
        // outer chunk header: type=RES_XML_TYPE, headerSize=8
        out[0] = 0x03; out[1] = 0x00 // type 0x0003
        out[2] = 0x08; out[3] = 0x00 // headerSize 8
        BinaryCursor.patchU32(out, 4, out.size) // total size, filled after we know out.size
        System.arraycopy(newPoolBytes, 0, out, 8, newPoolBytes.size)
        System.arraycopy(tail, 0, out, 8 + newPoolBytes.size, tail.size)
        return out
    }

    private fun strAt(strings: List<String>, idx: Int): String? =
        if (idx in strings.indices) strings[idx] else null
}
