package com.liatools.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// System font family for now; swap for a bundled font later if brand needs it.
val LiaFontFamily = FontFamily.Default

val LiaTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = LiaFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 30.sp,
        color = LiaTextPrimary
    ),
    headlineSmall = TextStyle(
        fontFamily = LiaFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        color = LiaTextPrimary
    ),
    titleLarge = TextStyle(
        fontFamily = LiaFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        color = LiaTextPrimary
    ),
    bodyLarge = TextStyle(
        fontFamily = LiaFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        color = LiaTextPrimary
    ),
    bodyMedium = TextStyle(
        fontFamily = LiaFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        color = LiaTextSecondary
    ),
    labelLarge = TextStyle(
        fontFamily = LiaFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        color = LiaTextPrimary
    ),
    labelSmall = TextStyle(
        fontFamily = LiaFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        color = LiaTextSecondary
    )
)
