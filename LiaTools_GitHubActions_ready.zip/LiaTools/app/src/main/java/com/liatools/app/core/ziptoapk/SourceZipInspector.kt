package com.liatools.app.core.ziptoapk

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * Reads the user-selected project ZIP (Step 1), validates it's something we can
 * actually wrap into a WebView shell, and extracts it into a private working
 * directory the [com.liatools.app.core.ziptoapk.ApkBuilder] can then package.
 */
class SourceZipInspector(private val context: Context) {

    class InvalidZipException(message: String) : Exception(message)

    data class InspectionResult(
        val extractedDir: File,
        val entryCount: Int,
        val hasIndexHtml: Boolean
    )

    /**
     * Extracts [zipUri] into [destinationDir] (cleared first). Guards against
     * zip-slip path traversal (entries like "../../etc/passwd") which is a classic
     * vulnerability in naive ZIP extraction code.
     */
    fun extract(zipUri: Uri, destinationDir: File): InspectionResult {
        destinationDir.deleteRecursively()
        destinationDir.mkdirs()

        val canonicalRoot = destinationDir.canonicalPath
        var entryCount = 0
        var hasIndexHtml = false

        val input = context.contentResolver.openInputStream(zipUri)
            ?: throw InvalidZipException("Couldn't open the selected ZIP file.")

        ZipInputStream(input.buffered()).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            if (entry == null) throw InvalidZipException("The selected file isn't a valid ZIP archive (no entries found).")

            while (entry != null) {
                val name = entry.name
                val outFile = File(destinationDir, name)
                val canonicalOut = outFile.canonicalPath

                if (!canonicalOut.startsWith(canonicalRoot + File.separator) && canonicalOut != canonicalRoot) {
                    // zip-slip guard: refuse to write outside the extraction root
                    throw InvalidZipException("Unsafe entry path in ZIP: $name")
                }

                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    outFile.outputStream().use { fos -> zis.copyTo(fos) }
                    entryCount++
                    val lower = name.lowercase()
                    if (lower == "index.html" || lower.endsWith("/index.html")) hasIndexHtml = true
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        if (entryCount == 0) throw InvalidZipException("The ZIP archive is empty.")
        return InspectionResult(destinationDir, entryCount, hasIndexHtml)
    }

    /** Best-effort display name for the picked ZIP, shown on Step 1. */
    fun displayName(uri: Uri): String {
        var name: String? = null
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
            }
        } catch (_: IOException) {
            // fall through to uri fallback below
        }
        return name ?: uri.lastPathSegment ?: "selected.zip"
    }
}
