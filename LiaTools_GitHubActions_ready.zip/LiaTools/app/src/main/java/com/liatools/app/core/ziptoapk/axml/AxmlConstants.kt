package com.liatools.app.core.ziptoapk.axml

/**
 * Chunk type codes and Res_value dataType codes from AOSP's
 * frameworks/base/libs/androidfw/include/androidfw/ResourceTypes.h.
 * These are stable, documented parts of the APK binary XML format.
 */
object AxmlConstants {
    const val RES_STRING_POOL_TYPE = 0x0001
    const val RES_XML_TYPE = 0x0003
    const val RES_XML_START_NAMESPACE_TYPE = 0x0100
    const val RES_XML_END_NAMESPACE_TYPE = 0x0101
    const val RES_XML_START_ELEMENT_TYPE = 0x0102
    const val RES_XML_END_ELEMENT_TYPE = 0x0103
    const val RES_XML_CDATA_TYPE = 0x0104
    const val RES_XML_RESOURCE_MAP_TYPE = 0x0180

    const val TYPE_STRING = 0x03
    const val TYPE_INT_DEC = 0x10

    const val STRING_POOL_UTF8_FLAG = 1 shl 8

    const val ANDROID_NS = "http://schemas.android.com/apk/res/android"
}
