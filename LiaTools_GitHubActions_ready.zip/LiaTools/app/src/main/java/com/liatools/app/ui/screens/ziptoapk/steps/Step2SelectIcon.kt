package com.liatools.app.ui.screens.ziptoapk.steps

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.liatools.app.core.ziptoapk.model.AppBuildConfig
import com.liatools.app.ui.theme.LiaTextSecondary

@Composable
fun Step2SelectIcon(
    config: AppBuildConfig,
    onIconPicked: (android.net.Uri) -> Unit
) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { onIconPicked(it) }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text(
            "Pick a square image to use as your app's launcher icon.",
            style = MaterialTheme.typography.bodyMedium,
            color = LiaTextSecondary
        )

        Box(
            modifier = Modifier
                .size(140.dp)
                .clip(RoundedCornerShape(32.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (config.iconUri != null) {
                AsyncImage(
                    model = config.iconUri,
                    contentDescription = "App icon preview",
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxSize()) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            imageVector = Icons.Filled.Image,
                            contentDescription = null,
                            tint = LiaTextSecondary,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }
            }
        }

        OutlinedButton(onClick = { launcher.launch("image/*") }) {
            Text(if (config.isStep2Valid()) "Choose a different icon" else "Choose icon (PNG or JPG)")
        }

        Text(
            "The icon is automatically resized for every screen density.",
            style = MaterialTheme.typography.bodyMedium,
            color = LiaTextSecondary
        )
    }
}
