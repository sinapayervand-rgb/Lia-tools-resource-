# Add project specific ProGuard rules here.
# Lia Tools currently ships with minifyEnabled=false for v1, kept simple
# so future tool modules don't fight obfuscation while the architecture settles.
