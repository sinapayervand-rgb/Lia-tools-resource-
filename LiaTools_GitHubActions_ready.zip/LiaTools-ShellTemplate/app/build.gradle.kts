plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.liatools.shell"
    compileSdk = 34

    defaultConfig {
        // These are placeholders — Lia Tools overwrites package/versionName/versionCode
        // by patching the compiled AndroidManifest.xml at build time (see
        // core/ziptoapk/axml/AxmlManifestPatcher.kt in the main app). What you set
        // here only matters for building/testing this shell on its own.
        applicationId = "com.liatools.shell.template"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
}
