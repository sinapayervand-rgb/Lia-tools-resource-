package com.liatools.shell

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

/**
 * The entire runtime behavior of every APK Lia Tools produces. It does exactly
 * one thing: load the web project that was zipped into assets/www/ at build
 * time. Lia Tools never modifies this class — it only swaps assets/www/ and
 * the launcher icon, and patches the manifest's identity fields. Keep this
 * activity boring and stable; any real feature work belongs in the web
 * project itself, not here.
 */
class ShellMainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shell_main)

        webView = findViewById(R.id.shellWebView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
        }
        webView.webViewClient = WebViewClient()
        webView.loadUrl("file:///android_asset/www/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
