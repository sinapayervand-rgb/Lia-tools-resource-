package com.liatools.shell

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

/**
 * The entire runtime behavior of every APK Lia Tools produces. Lia Tools never
 * modifies this class — it only swaps assets/www/, the launcher icon, and a
 * few manifest identity fields. Any real feature work belongs in the web
 * project itself. What lives here is the "professional WebView shell"
 * baseline every generated app gets automatically, with no per-build toggle:
 *
 *  - File upload (<input type="file">), including "capture from camera"
 *  - Native JavaScript alert/confirm/prompt dialogs
 *  - Downloads (via the system DownloadManager, visible in Downloads/Notifications)
 *  - External links open in the device's browser instead of breaking the WebView
 *  - Local Storage / DOM storage enabled
 *  - Geolocation (optional — only used if the web page actually requests it)
 *  - Runtime permission handling for camera / microphone / location
 */
class ShellMainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    // --- File upload (+ camera capture) plumbing --------------------------------
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private var pendingCameraPhotoUri: Uri? = null

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = fileUploadCallback
        fileUploadCallback = null
        if (callback == null) return@registerForActivityResult

        val data = result.data
        val results: Array<Uri>? = when {
            result.resultCode != Activity.RESULT_OK -> null
            data?.dataString != null -> arrayOf(Uri.parse(data.dataString))
            data?.clipData != null -> {
                val clip = data.clipData!!
                Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
            }
            pendingCameraPhotoUri != null -> arrayOf(pendingCameraPhotoUri!!)
            else -> null
        }
        callback.onReceiveValue(results)
        pendingCameraPhotoUri = null
    }

    // Runtime permissions needed before we can safely hand camera/mic/location to the WebView.
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* results observed lazily via ContextCompat.checkSelfPermission where needed */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shell_main)

        webView = findViewById(R.id.shellWebView)
        configureWebView(webView)
        webView.loadUrl("file:///android_asset/www/index.html")

        requestRuntimePermissionsUpfront()
    }

    private fun configureWebView(webView: WebView) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            setGeolocationEnabled(true)
            setSupportMultipleWindows(false)
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            // Keep navigation to the app's own bundled pages inside the WebView;
            // send anything else (http/https links to other sites, mailto:, tel:, etc.)
            // out to the appropriate system app instead of trying to load it in-app.
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme?.lowercase()
                return when {
                    scheme == "file" -> false // internal navigation within assets/www — let the WebView handle it
                    scheme == "http" || scheme == "https" -> {
                        openExternally(uri)
                        true
                    }
                    else -> {
                        // mailto:, tel:, intent:, market:, etc.
                        openExternally(uri)
                        true
                    }
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {

            // --- JavaScript dialogs, shown as real native dialogs -----------------
            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@ShellMainActivity)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@ShellMainActivity)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            // --- File upload (+ camera capture) ------------------------------------
            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback

                val intents = mutableListOf<Intent>()

                // Offer "take a photo" as one of the chooser options when camera hardware exists.
                if (packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_CAMERA_ANY)) {
                    val photoFile = try { createTempImageFile() } catch (_: Exception) { null }
                    if (photoFile != null) {
                        val photoUri = FileProvider.getUriForFile(
                            this@ShellMainActivity, "$packageName.fileprovider", photoFile
                        )
                        pendingCameraPhotoUri = photoUri
                        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                            putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
                            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                        }
                        if (cameraIntent.resolveActivity(packageManager) != null) intents.add(cameraIntent)
                    }
                }

                val contentIntent = fileChooserParams.createIntent()
                val chooser = Intent(Intent.ACTION_CHOOSER).apply {
                    putExtra(Intent.EXTRA_INTENT, contentIntent)
                    putExtra(Intent.EXTRA_INITIAL_INTENTS, intents.toTypedArray())
                }
                return try {
                    fileChooserLauncher.launch(chooser)
                    true
                } catch (_: Exception) {
                    fileUploadCallback = null
                    false
                }
            }

            // --- Camera / microphone access requested by page JS (e.g. getUserMedia) ---
            override fun onPermissionRequest(request: PermissionRequest) {
                val needsCamera = request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                val needsMic = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                val cameraOk = !needsCamera || hasPermission(Manifest.permission.CAMERA)
                val micOk = !needsMic || hasPermission(Manifest.permission.RECORD_AUDIO)
                runOnUiThread {
                    if (cameraOk && micOk) request.grant(request.resources) else request.deny()
                }
            }

            // --- Geolocation: only asked for if the page actually calls navigator.geolocation ---
            override fun onGeolocationPermissionsShowPrompt(
                origin: String,
                callback: GeolocationPermissions.Callback
            ) {
                val granted = hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) ||
                    hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                callback.invoke(origin, granted, false)
            }
        }

        // --- Downloads: hand off to the system DownloadManager -------------------------
        webView.setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            try {
                val request = DownloadManager.Request(Uri.parse(url)).apply {
                    setMimeType(mimeType)
                    addRequestHeader("User-Agent", webView.settings.userAgentString)
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                }
                val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(request)
                Toast.makeText(this, "Downloading…", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Couldn't start download: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openExternally(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) {
            Toast.makeText(this, "No app found to open this link", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hasPermission(permission: String): Boolean =
        checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    /** Ask once upfront for the permissions this WebView baseline might need, so runtime prompts feel less abrupt. */
    private fun requestRuntimePermissionsUpfront() {
        val wanted = mutableListOf(Manifest.permission.CAMERA)
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q) {
            wanted.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val notGranted = wanted.filter { !hasPermission(it) }
        if (notGranted.isNotEmpty()) permissionLauncher.launch(notGranted.toTypedArray())
    }

    private fun createTempImageFile(): File {
        val dir = File(cacheDir, "camera").apply { mkdirs() }
        return File.createTempFile("capture_", ".jpg", dir)
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
