package com.liatools.app.core.ziptoapk.sign

import android.content.Context
import java.io.File
import java.security.MessageDigest
import java.util.Base64
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Signs an unsigned APK using APK Signature Scheme v1 (the original JAR-signing
 * scheme: META-INF/MANIFEST.MF + META-INF/CERT.SF + META-INF/CERT.RSA). Every
 * Android version accepts v1 signatures, which is why it's what an on-device,
 * dependency-free signer targets — reproducing v2/v3 (APK Signing Block) would
 * need a full block-format implementation for no real benefit here.
 *
 * Accepts any [DebugKeystoreProvider.SigningIdentity] — the bundled debug key
 * by default, or a user-supplied keystore loaded via [CustomKeystoreProvider]
 * when Step 3's optional custom-signing section is used.
 *
 * Known simplification: output isn't zipaligned. Zipalign only affects runtime
 * mmap performance of resources, not installability.
 */
class ApkSigner(private val context: Context) {

    class SigningException(message: String, cause: Throwable? = null) : Exception(message, cause)

    fun sign(
        unsignedApk: File,
        signedApkOut: File,
        identity: DebugKeystoreProvider.SigningIdentity,
        onLog: (String) -> Unit = {}
    ) {
        try {
            val digests = LinkedHashMap<String, String>() // entry name -> base64 SHA-256
            val manifestBuilder = StringBuilder()
            manifestBuilder.append("Manifest-Version: 1.0\r\n")
            manifestBuilder.append("Created-By: Lia Tools\r\n\r\n")

            ZipFile(unsignedApk).use { zip ->
                val names = zip.entries().toList()
                    .filterNot { it.name.startsWith("META-INF/") }
                    .map { it.name }
                    .sorted()

                for (name in names) {
                    val entry = zip.getEntry(name)
                    val bytes = zip.getInputStream(entry).use { it.readBytes() }
                    val digest = sha256Base64(bytes)
                    digests[name] = digest
                    manifestBuilder.append(manifestSection(name, digest))
                }
            }
            onLog("Computed SHA-256 digests for ${digests.size} entries")

            val manifestBytes = manifestBuilder.toString().toByteArray(Charsets.UTF_8)
            val manifestDigest = sha256Base64(manifestBytes)
            onLog("Built MANIFEST.MF (${manifestBytes.size} bytes)")

            val sfBuilder = StringBuilder()
            sfBuilder.append("Signature-Version: 1.0\r\n")
            sfBuilder.append(foldLine("SHA-256-Digest-Manifest: $manifestDigest"))
            sfBuilder.append("Created-By: Lia Tools\r\n\r\n")
            for ((name, _) in digests) {
                val sectionText = manifestSection(name, digests.getValue(name))
                val sectionDigest = sha256Base64(sectionText.toByteArray(Charsets.UTF_8))
                sfBuilder.append(manifestSection(name, sectionDigest))
            }
            val sfBytes = sfBuilder.toString().toByteArray(Charsets.UTF_8)
            onLog("Built CERT.SF (${sfBytes.size} bytes)")

            val certRsaBytes = Pkcs7SignedDataBuilder.build(sfBytes, identity.privateKey, identity.certificate)
            onLog("Signed with SHA256withRSA as ${identity.certificate.subjectX500Principal.name}")

            signedApkOut.parentFile?.mkdirs()
            ZipFile(unsignedApk).use { zip ->
                ZipOutputStream(signedApkOut.outputStream().buffered()).use { zos ->
                    for (entry in zip.entries().toList().filterNot { it.name.startsWith("META-INF/") }) {
                        val bytes = zip.getInputStream(entry).use { it.readBytes() }
                        writeEntry(zos, entry.name, bytes)
                    }
                    writeEntry(zos, "META-INF/MANIFEST.MF", manifestBytes)
                    writeEntry(zos, "META-INF/CERT.SF", sfBytes)
                    writeEntry(zos, "META-INF/CERT.RSA", certRsaBytes)
                }
            }
            onLog("Wrote signed APK: ${signedApkOut.name} (${signedApkOut.length()} bytes)")
        } catch (e: Exception) {
            throw SigningException("Failed to sign the APK: ${e.message}", e)
        }
    }

    private fun writeEntry(zos: ZipOutputStream, name: String, bytes: ByteArray) {
        val entry = ZipEntry(name)
        entry.method = ZipEntry.DEFLATED
        zos.putNextEntry(entry)
        zos.write(bytes)
        zos.closeEntry()
    }

    private fun manifestSection(name: String, digestBase64: String): String {
        val sb = StringBuilder()
        sb.append(foldLine("Name: $name"))
        sb.append(foldLine("SHA-256-Digest: $digestBase64"))
        sb.append("\r\n")
        return sb.toString()
    }

    /** JAR manifest spec: no physical line may exceed 72 bytes; continuations start with a single space. */
    private fun foldLine(line: String): String {
        val bytes = line.toByteArray(Charsets.UTF_8)
        if (bytes.size <= 72) return line + "\r\n"
        val sb = StringBuilder()
        var offset = 0
        var first = true
        while (offset < bytes.size) {
            val chunkLen = if (first) minOf(72, bytes.size - offset) else minOf(71, bytes.size - offset)
            val chunk = String(bytes, offset, chunkLen, Charsets.UTF_8)
            sb.append(if (first) chunk else " $chunk")
            sb.append("\r\n")
            offset += chunkLen
            first = false
        }
        return sb.toString()
    }

    private fun sha256Base64(bytes: ByteArray): String =
        Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-256").digest(bytes))
}
