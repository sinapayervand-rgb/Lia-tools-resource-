package com.liatools.app.ui.screens.ziptoapk.steps

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.liatools.app.core.ziptoapk.model.AppBuildConfig
import com.liatools.app.ui.components.LiaCard
import com.liatools.app.ui.theme.LiaTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Step3AppInfo(
    config: AppBuildConfig,
    onAppNameChanged: (String) -> Unit,
    onPackageNameChanged: (String) -> Unit,
    onVersionNameChanged: (String) -> Unit,
    onVersionCodeChanged: (Int) -> Unit,
    onDescriptionChanged: (String) -> Unit,
    onUseCustomKeystoreToggled: (Boolean) -> Unit,
    onKeystoreSelected: (android.net.Uri, String) -> Unit,
    onKeystorePasswordChanged: (String) -> Unit,
    onKeyAliasChanged: (String) -> Unit,
    onKeyPasswordChanged: (String) -> Unit
) {
    val context = LocalContext.current
    val keystoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            var name = uri.lastPathSegment ?: "keystore"
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) name = c.getString(idx)
            }
            onKeystoreSelected(uri, name)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        OutlinedTextField(
            value = config.appName,
            onValueChange = onAppNameChanged,
            label = { Text("Application Name") },
            placeholder = { Text("My App") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = config.packageName,
            onValueChange = onPackageNameChanged,
            label = { Text("Package Name") },
            placeholder = { Text("com.example.myapp") },
            singleLine = true,
            isError = config.packageNameError() != null,
            supportingText = {
                config.packageNameError()?.let { Text(it) }
            },
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = config.versionName,
                onValueChange = onVersionNameChanged,
                label = { Text("Version Name") },
                placeholder = { Text("1.0") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = config.versionCode.toString(),
                onValueChange = { v -> v.toIntOrNull()?.let(onVersionCodeChanged) },
                label = { Text("Version Code") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
        }

        OutlinedTextField(
            value = config.description,
            onValueChange = onDescriptionChanged,
            label = { Text("App Description") },
            placeholder = { Text("What does your app do?") },
            minLines = 3,
            maxLines = 5,
            modifier = Modifier.fillMaxWidth()
        )

        LiaCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Key, contentDescription = null, tint = LiaTextSecondary)
                Spacer(Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Custom release signing", style = MaterialTheme.typography.labelLarge)
                    Text(
                        "Off by default — Lia Tools signs with its own debug key.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = LiaTextSecondary
                    )
                }
                Switch(checked = config.useCustomKeystore, onCheckedChange = onUseCustomKeystoreToggled)
            }

            if (config.useCustomKeystore) {
                Spacer(Modifier.height(16.dp))
                OutlinedButton(
                    onClick = { keystoreLauncher.launch(arrayOf("application/octet-stream", "*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(config.keystoreName ?: "Choose keystore file (.jks / .keystore)")
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = config.keystorePassword,
                    onValueChange = onKeystorePasswordChanged,
                    label = { Text("Keystore password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = config.keyAlias,
                    onValueChange = onKeyAliasChanged,
                    label = { Text("Key alias (leave blank to use the first one found)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = config.keyPassword,
                    onValueChange = onKeyPasswordChanged,
                    label = { Text("Key password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}
