package com.liatools.app.core.ziptoapk.model

import android.net.Uri

/** User-provided inputs collected across the wizard's 4 steps. */
data class AppBuildConfig(
    // Step 1
    val sourceZipUri: Uri? = null,
    val sourceZipName: String? = null,

    // Step 2
    val iconUri: Uri? = null,

    // Step 3
    val appName: String = "",
    val packageName: String = "",
    val versionName: String = "1.0",
    val versionCode: Int = 1,
    val description: String = "",

    // Step 3 — optional custom release signing (falls back to the bundled debug key when disabled)
    val useCustomKeystore: Boolean = false,
    val keystoreUri: Uri? = null,
    val keystoreName: String? = null,
    val keystorePassword: String = "",
    val keyAlias: String = "",
    val keyPassword: String = ""
) {
    fun isStep1Valid() = sourceZipUri != null
    fun isStep2Valid() = iconUri != null

    fun isStep3Valid(): Boolean =
        appName.isNotBlank() &&
            PACKAGE_NAME_REGEX.matches(packageName) &&
            versionName.isNotBlank() &&
            versionCode >= 1 &&
            (!useCustomKeystore || isCustomKeystoreValid())

    fun isCustomKeystoreValid(): Boolean =
        keystoreUri != null && keystorePassword.isNotBlank() && keyPassword.isNotBlank()

    fun packageNameError(): String? = when {
        packageName.isBlank() -> null
        !PACKAGE_NAME_REGEX.matches(packageName) ->
            "Use reverse-domain format, e.g. com.example.myapp (lowercase, no spaces)"
        else -> null
    }

    companion object {
        // At least two segments, each starting with a letter, letters/digits/underscore only.
        val PACKAGE_NAME_REGEX = Regex("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$")
    }
}
