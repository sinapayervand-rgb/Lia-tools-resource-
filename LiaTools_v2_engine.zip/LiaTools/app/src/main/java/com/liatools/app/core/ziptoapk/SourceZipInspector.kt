package com.liatools.app.core.ziptoapk

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * Reads the user-selected project ZIP (Step 1), validates it's something we can
 * actually wrap into a WebView shell, and extracts it into a private working
 * directory the [com.liatools.app.core.ziptoapk.ApkBuilder] can then package.
 *
 * This is the "accept almost any real-world export ZIP without the user having
 * to restructure it first" layer — the two problems that break naive
 * extract-and-copy tools:
 *   1. Many site exports (and every GitHub "Download ZIP") wrap the whole
 *      project in one extra top-level folder, so index.html ends up at
 *      "my-site-main/index.html" instead of the archive root.
 *   2. Editors on case-preserving filesystems (Windows, macOS) sometimes save
 *      "Index.html" — harmless there, but file:///android_asset/index.html
 *      is case-sensitive on Android and would 404.
 * Both are handled automatically below so the wizard "just works" for typical
 * exports without asking the user to fix their ZIP first.
 */
class SourceZipInspector(private val context: Context) {

    class InvalidZipException(message: String) : Exception(message)

    data class InspectionResult(
        /** The directory that actually contains index.html — use this, not the raw extraction dir, when building. */
        val webRootDir: File,
        val entryCount: Int
    )

    /**
     * Extracts [zipUri] into [destinationDir] (cleared first), guarding against
     * zip-slip path traversal (entries like "../../etc/passwd"), then resolves
     * the real web root as described in the class doc.
     */
    fun extract(zipUri: Uri, destinationDir: File): InspectionResult {
        destinationDir.deleteRecursively()
        destinationDir.mkdirs()

        val canonicalRoot = destinationDir.canonicalPath
        var entryCount = 0

        val input = context.contentResolver.openInputStream(zipUri)
            ?: throw InvalidZipException("Couldn't open the selected ZIP file.")

        ZipInputStream(input.buffered()).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            if (entry == null) throw InvalidZipException("The selected file isn't a valid ZIP archive (no entries found).")

            while (entry != null) {
                val name = entry.name
                val outFile = File(destinationDir, name)
                val canonicalOut = outFile.canonicalPath

                if (!canonicalOut.startsWith(canonicalRoot + File.separator) && canonicalOut != canonicalRoot) {
                    // zip-slip guard: refuse to write outside the extraction root
                    throw InvalidZipException("Unsafe entry path in ZIP: $name")
                }

                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    outFile.outputStream().use { fos -> zis.copyTo(fos) }
                    entryCount++
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        if (entryCount == 0) throw InvalidZipException("The ZIP archive is empty.")

        val webRoot = resolveWebRoot(destinationDir)
            ?: throw InvalidZipException(
                "No index.html found anywhere in the ZIP. Every web project needs an index.html " +
                    "at its root (or inside a single top-level folder) as the entry point."
            )
        normalizeIndexCase(webRoot)

        return InspectionResult(webRoot, entryCount)
    }

    /**
     * Finds the directory that should be treated as the web root:
     *  - index.html directly in [extractedDir] -> that's the root.
     *  - otherwise, if [extractedDir] contains exactly one item and it's a
     *    directory, unwrap into it and check there too (recursively, in case
     *    of doubly-wrapped archives).
     *  - otherwise, fall back to a full recursive search and use whichever
     *    directory holds the shallowest index.html found.
     */
    private fun resolveWebRoot(extractedDir: File): File? {
        if (hasIndexHtml(extractedDir)) return extractedDir

        var current = extractedDir
        while (true) {
            val children = current.listFiles() ?: break
            val onlyDir = children.singleOrNull { it.isDirectory }
            if (children.size == 1 && onlyDir != null) {
                current = onlyDir
                if (hasIndexHtml(current)) return current
            } else {
                break
            }
        }

        // Fallback: search the whole tree, prefer the shallowest match.
        var best: File? = null
        var bestDepth = Int.MAX_VALUE
        extractedDir.walkTopDown().forEach { f ->
            if (f.isDirectory && hasIndexHtml(f)) {
                val depth = f.relativeTo(extractedDir).path.count { it == File.separatorChar }
                if (depth < bestDepth) { best = f; bestDepth = depth }
            }
        }
        return best
    }

    private fun hasIndexHtml(dir: File): Boolean =
        dir.listFiles()?.any { it.isFile && it.name.equals("index.html", ignoreCase = true) } == true

    /** Ensures the entry file is exactly lowercase "index.html" so the shell's hardcoded load URL always resolves. */
    private fun normalizeIndexCase(webRoot: File) {
        val exact = File(webRoot, "index.html")
        if (exact.exists()) return
        val actual = webRoot.listFiles()?.firstOrNull { it.isFile && it.name.equals("index.html", ignoreCase = true) }
        actual?.copyTo(exact, overwrite = true)
    }

    /** Best-effort display name for the picked ZIP, shown on Step 1. */
    fun displayName(uri: Uri): String {
        var name: String? = null
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
            }
        } catch (_: IOException) {
            // fall through to uri fallback below
        }
        return name ?: uri.lastPathSegment ?: "selected.zip"
    }
}
