package com.liatools.app.ui.screens.ziptoapk

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.liatools.app.core.ziptoapk.SourceZipInspector
import com.liatools.app.core.ziptoapk.ZipToApkBuildPipeline
import com.liatools.app.core.ziptoapk.model.AppBuildConfig
import com.liatools.app.core.ziptoapk.model.BuildEvent
import com.liatools.app.core.ziptoapk.model.BuildStage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

/** Which of the 4 wizard screens is currently visible. */
enum class WizardStep(val index: Int, val title: String) {
    SELECT_ZIP(0, "Select ZIP File"),
    SELECT_ICON(1, "Select App Icon"),
    APP_INFO(2, "Application Information"),
    BUILD(3, "Build APK");

    companion object {
        val ORDERED = entries.sortedBy { it.index }
    }
}

data class BuildUiState(
    val isBuilding: Boolean = false,
    val stage: BuildStage? = null,
    val percent: Int = 0,
    val detail: String? = null,
    val logLines: List<String> = emptyList(),
    val errorMessage: String? = null,
    val errorStackTrace: String? = null,
    val resultFile: File? = null
)

data class WizardUiState(
    val currentStep: WizardStep = WizardStep.SELECT_ZIP,
    val config: AppBuildConfig = AppBuildConfig(),
    val build: BuildUiState = BuildUiState()
)

class ZipToApkViewModel(application: Application) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(WizardUiState())
    val state: StateFlow<WizardUiState> = _state.asStateFlow()

    private val zipInspector = SourceZipInspector(application)
    private val pipeline = ZipToApkBuildPipeline(application)

    // --- Step navigation -----------------------------------------------------

    fun goNext() {
        val current = _state.value.currentStep
        val next = WizardStep.ORDERED.getOrNull(current.index + 1) ?: return
        _state.update { it.copy(currentStep = next) }
    }

    fun goBack(): Boolean {
        val current = _state.value.currentStep
        val prev = WizardStep.ORDERED.getOrNull(current.index - 1)
        return if (prev != null) {
            _state.update { it.copy(currentStep = prev) }
            true
        } else {
            false // caller should navigate up out of the wizard
        }
    }

    fun canProceedFromCurrentStep(): Boolean {
        val cfg = _state.value.config
        return when (_state.value.currentStep) {
            WizardStep.SELECT_ZIP -> cfg.isStep1Valid()
            WizardStep.SELECT_ICON -> cfg.isStep2Valid()
            WizardStep.APP_INFO -> cfg.isStep3Valid()
            WizardStep.BUILD -> true
        }
    }

    // --- Step 1: ZIP ----------------------------------------------------------

    fun onZipSelected(uri: Uri) {
        val name = zipInspector.displayName(uri)
        _state.update { it.copy(config = it.config.copy(sourceZipUri = uri, sourceZipName = name)) }
    }

    // --- Step 2: Icon -----------------------------------------------------------

    fun onIconSelected(uri: Uri) {
        _state.update { it.copy(config = it.config.copy(iconUri = uri)) }
    }

    // --- Step 3: App info ---------------------------------------------------------

    fun onAppNameChanged(v: String) {
        _state.update { it.copy(config = it.config.copy(appName = v)) }
        maybeSuggestPackageName()
    }
    fun onPackageNameChanged(v: String) = _state.update { it.copy(config = it.config.copy(packageName = v)) }
    fun onVersionNameChanged(v: String) = _state.update { it.copy(config = it.config.copy(versionName = v)) }
    fun onVersionCodeChanged(v: Int) = _state.update { it.copy(config = it.config.copy(versionCode = v)) }
    fun onDescriptionChanged(v: String) = _state.update { it.copy(config = it.config.copy(description = v)) }

    /** Small UX nicety: once the user types an app name, prefill a sane package name if they haven't set one. */
    private fun maybeSuggestPackageName() {
        val cfg = _state.value.config
        if (cfg.packageName.isNotBlank()) return
        val slug = cfg.appName.lowercase()
            .replace(Regex("[^a-z0-9]+"), "")
            .ifBlank { "myapp" }
        _state.update { it.copy(config = it.config.copy(packageName = "com.example.$slug")) }
    }

    // --- Step 3: optional custom release signing -------------------------------

    fun onUseCustomKeystoreToggled(enabled: Boolean) =
        _state.update { it.copy(config = it.config.copy(useCustomKeystore = enabled)) }

    fun onKeystoreSelected(uri: Uri, displayName: String) =
        _state.update { it.copy(config = it.config.copy(keystoreUri = uri, keystoreName = displayName)) }

    fun onKeystorePasswordChanged(v: String) = _state.update { it.copy(config = it.config.copy(keystorePassword = v)) }
    fun onKeyAliasChanged(v: String) = _state.update { it.copy(config = it.config.copy(keyAlias = v)) }
    fun onKeyPasswordChanged(v: String) = _state.update { it.copy(config = it.config.copy(keyPassword = v)) }

    // --- Step 4: Build ----------------------------------------------------------

    fun startBuild() {
        if (_state.value.build.isBuilding) return
        _state.update { it.copy(build = BuildUiState(isBuilding = true)) }
        viewModelScope.launch {
            pipeline.run(_state.value.config).collect { event ->
                when (event) {
                    is BuildEvent.Progress -> _state.update {
                        it.copy(build = it.build.copy(stage = event.stage, percent = event.percent, detail = event.detail))
                    }
                    is BuildEvent.Log -> _state.update {
                        it.copy(build = it.build.copy(logLines = it.build.logLines + event.message))
                    }
                    is BuildEvent.Success -> _state.update {
                        it.copy(build = it.build.copy(isBuilding = false, resultFile = event.outputFile, percent = 100))
                    }
                    is BuildEvent.Failure -> _state.update {
                        it.copy(build = it.build.copy(
                            isBuilding = false,
                            errorMessage = event.message,
                            errorStackTrace = event.stackTrace
                        ))
                    }
                }
            }
        }
    }

    fun retryBuild() {
        _state.update { it.copy(build = BuildUiState()) }
        startBuild()
    }
}
