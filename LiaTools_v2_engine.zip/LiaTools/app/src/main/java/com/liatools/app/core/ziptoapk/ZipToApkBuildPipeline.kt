package com.liatools.app.core.ziptoapk

import android.content.Context
import com.liatools.app.core.ziptoapk.model.AppBuildConfig
import com.liatools.app.core.ziptoapk.model.BuildEvent
import com.liatools.app.core.ziptoapk.model.BuildStage
import com.liatools.app.core.ziptoapk.sign.ApkSigner
import com.liatools.app.core.ziptoapk.sign.CustomKeystoreProvider
import com.liatools.app.core.ziptoapk.sign.DebugKeystoreProvider
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.Dispatchers
import java.io.File

/**
 * Step 4's engine. Runs entirely offline: extract -> process icon -> patch
 * manifest & assemble -> sign. Emits [BuildEvent]s so the UI can show live
 * progress and a full build log instead of a blind spinner.
 */
class ZipToApkBuildPipeline(private val context: Context) {

    fun run(config: AppBuildConfig): Flow<BuildEvent> = flow {
        val workDir = File(context.cacheDir, "lia_build_work").apply { mkdirs() }
        val extractedDir = File(workDir, "extracted")
        val unsignedApk = File(workDir, "unsigned.apk")
        val signedApk = File(context.getExternalFilesDir("output"), outputFileName(config))

        try {
            emit(BuildEvent.Progress(BuildStage.VALIDATING_ZIP, 5))
            val zipUri = config.sourceZipUri
                ?: return@flow emit(BuildEvent.Failure(BuildStage.VALIDATING_ZIP, "No ZIP file selected."))
            val iconUri = config.iconUri
                ?: return@flow emit(BuildEvent.Failure(BuildStage.PROCESSING_ICON, "No app icon selected."))

            emit(BuildEvent.Progress(BuildStage.EXTRACTING, 15, "Reading ${config.sourceZipName ?: "ZIP"}"))
            val inspection = SourceZipInspector(context).extract(zipUri, extractedDir)
            emit(BuildEvent.Log("Extracted ${inspection.entryCount} files; web root resolved to ${inspection.webRootDir.name}"))

            emit(BuildEvent.Progress(BuildStage.PROCESSING_ICON, 30))
            val iconBitmap = IconProcessor(context).decode(iconUri)

            emit(BuildEvent.Progress(BuildStage.PATCHING_MANIFEST, 45, "Applying ${config.appName} / ${config.packageName}"))
            emit(BuildEvent.Progress(BuildStage.ASSEMBLING_APK, 55, "${inspection.entryCount} files"))

            val buildLogs = mutableListOf<String>()
            ApkBuilder(context).build(
                webRootDir = inspection.webRootDir,
                icon = iconBitmap,
                appName = config.appName,
                packageName = config.packageName,
                versionName = config.versionName,
                versionCode = config.versionCode,
                outputApk = unsignedApk,
                onLog = { buildLogs.add(it) }
            )
            for (line in buildLogs) emit(BuildEvent.Log(line))

            emit(BuildEvent.Progress(BuildStage.SIGNING, 85,
                if (config.useCustomKeystore) "Signing with your keystore (${config.keystoreName ?: "custom"})"
                else "Signing with Lia Tools debug key"
            ))

            val identity = if (config.useCustomKeystore) {
                val uri = config.keystoreUri
                    ?: return@flow emit(BuildEvent.Failure(BuildStage.SIGNING, "Custom signing is enabled but no keystore file was selected."))
                try {
                    CustomKeystoreProvider(context).load(uri, config.keystorePassword, config.keyAlias, config.keyPassword)
                } catch (e: CustomKeystoreProvider.InvalidKeystoreException) {
                    return@flow emit(BuildEvent.Failure(BuildStage.SIGNING, e.message ?: "Invalid keystore.", e))
                }
            } else {
                DebugKeystoreProvider(context).load()
            }

            val signLogs = mutableListOf<String>()
            ApkSigner(context).sign(unsignedApk, signedApk, identity, onLog = { signLogs.add(it) })
            for (line in signLogs) emit(BuildEvent.Log(line))

            emit(BuildEvent.Progress(BuildStage.DONE, 100))
            emit(BuildEvent.Success(signedApk))
        } catch (e: SourceZipInspector.InvalidZipException) {
            emit(BuildEvent.Failure(BuildStage.VALIDATING_ZIP, e.message ?: "Invalid ZIP file.", e))
        } catch (e: IconProcessor.InvalidIconException) {
            emit(BuildEvent.Failure(BuildStage.PROCESSING_ICON, e.message ?: "Invalid icon image.", e))
        } catch (e: ApkBuilder.TemplateMissingException) {
            emit(BuildEvent.Failure(BuildStage.ASSEMBLING_APK, e.message ?: "Shell template missing.", e))
        } catch (e: ApkBuilder.BuildException) {
            emit(BuildEvent.Failure(BuildStage.ASSEMBLING_APK, e.message ?: "Failed to assemble APK.", e))
        } catch (e: ApkSigner.SigningException) {
            emit(BuildEvent.Failure(BuildStage.SIGNING, e.message ?: "Failed to sign APK.", e))
        } catch (e: Exception) {
            emit(BuildEvent.Failure(BuildStage.ASSEMBLING_APK, "Unexpected error: ${e.message}", e))
        }
    }.flowOn(Dispatchers.IO)

    private fun outputFileName(config: AppBuildConfig): String {
        val safeName = config.appName.ifBlank { "app" }
            .replace(Regex("[^A-Za-z0-9_-]+"), "_")
        return "${safeName}_${config.versionName}.apk"
    }
}
