package com.liatools.app.core.ziptoapk.model

/** Ordered stages the build pipeline reports, driving Step 4's progress UI. */
enum class BuildStage(val label: String) {
    VALIDATING_ZIP("Validating ZIP contents"),
    EXTRACTING("Extracting web assets"),
    PROCESSING_ICON("Processing app icon"),
    PATCHING_MANIFEST("Applying app identity (name, package, version)"),
    ASSEMBLING_APK("Assembling APK package"),
    SIGNING("Signing APK"),
    DONE("APK created successfully")
}

sealed class BuildEvent {
    data class Progress(val stage: BuildStage, val percent: Int, val detail: String? = null) : BuildEvent()
    /** One line for the scrollable build log in Step 4 — every meaningful thing the pipeline does. */
    data class Log(val message: String) : BuildEvent()
    data class Success(val outputFile: java.io.File) : BuildEvent()
    data class Failure(
        val stage: BuildStage,
        val message: String,
        val cause: Throwable? = null,
        /** Full stack trace text, shown in an expandable section so a real error can always be diagnosed. */
        val stackTrace: String? = cause?.stackTraceToString()
    ) : BuildEvent()
}
