package com.liatools.app.core.ziptoapk.sign

import android.content.Context
import android.net.Uri
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate

/**
 * Loads a keystore the user picked via the file chooser (Step 3's optional
 * "Custom signing" section), so builds can be signed with the developer's own
 * release key instead of Lia Tools' bundled debug key. Tries the common
 * keystore formats in order since a picked .jks/.keystore file's actual
 * format isn't knowable from its extension alone.
 */
class CustomKeystoreProvider(private val context: Context) {

    class InvalidKeystoreException(message: String, cause: Throwable? = null) : Exception(message, cause)

    fun load(
        keystoreUri: Uri,
        storePassword: String,
        keyAlias: String,
        keyPassword: String
    ): DebugKeystoreProvider.SigningIdentity {
        val bytes = context.contentResolver.openInputStream(keystoreUri)?.use { it.readBytes() }
            ?: throw InvalidKeystoreException("Couldn't read the selected keystore file.")

        var lastError: Exception? = null
        for (type in listOf("PKCS12", "JKS", "BKS")) {
            try {
                val ks = KeyStore.getInstance(type)
                ks.load(bytes.inputStream(), storePassword.toCharArray())

                val alias = keyAlias.ifBlank { ks.aliases().toList().firstOrNull() }
                    ?: throw InvalidKeystoreException("No aliases found in this keystore.")

                val key = ks.getKey(alias, keyPassword.toCharArray()) as? PrivateKey
                    ?: throw InvalidKeystoreException("Alias \"$alias\" has no private key (wrong alias, or wrong key password).")
                val cert = ks.getCertificate(alias) as? X509Certificate
                    ?: throw InvalidKeystoreException("Alias \"$alias\" has no certificate.")

                return DebugKeystoreProvider.SigningIdentity(key, cert)
            } catch (e: InvalidKeystoreException) {
                throw e
            } catch (e: Exception) {
                lastError = e // try the next keystore type
            }
        }
        throw InvalidKeystoreException(
            "Couldn't open this file as a keystore (tried PKCS12/JKS/BKS). Check the store password and that " +
                "the file is really a .keystore/.jks file.",
            lastError
        )
    }
}
