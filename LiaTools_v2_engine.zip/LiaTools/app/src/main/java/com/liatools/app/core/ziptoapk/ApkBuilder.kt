package com.liatools.app.core.ziptoapk

import android.content.Context
import android.graphics.Bitmap
import com.liatools.app.core.ziptoapk.axml.AxmlManifestPatcher
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Takes the bundled WebView "shell" template APK (assets/template/shell_template.apk —
 * built once via the companion LiaTools-ShellTemplate Gradle project, see its README)
 * and produces a new *unsigned* APK where:
 *   - assets/www/**            -> replaced with the user's extracted ZIP contents
 *   - res/mipmap-*/ic_launcher -> replaced with the user's chosen icon, per density
 *   - AndroidManifest.xml      -> package / versionName / versionCode / app label patched
 *
 * Everything else in the template (classes.dex, the WebView Activity, resources.arsc,
 * etc.) is copied through untouched. This "shell + asset swap" approach is what every
 * offline ZIP-to-APK tool does under the hood — building a real APK from scratch
 * on-device without the Android SDK's compiler/aapt2 isn't possible, but re-skinning
 * a prebuilt shell is, and it's exactly what step 4 needs to produce a real installable
 * APK.
 */
class ApkBuilder(private val context: Context) {

    class TemplateMissingException(message: String) : Exception(message)
    class BuildException(message: String, cause: Throwable? = null) : Exception(message, cause)

    companion object {
        const val TEMPLATE_ASSET_PATH = "template/shell_template.apk"
        const val MANIFEST_ENTRY = "AndroidManifest.xml"
        const val WWW_PREFIX = "assets/www/"

        // Matches res/mipmap-<density>[-v<api>]/ic_launcher[_round].png regardless of
        // whether aapt2 appended a version qualifier to the density folder name.
        private val ICON_ENTRY_REGEX =
            Regex("""res/mipmap-(mdpi|hdpi|xhdpi|xxhdpi|xxxhdpi)(?:-v\d+)?/ic_launcher(?:_round)?\.png""")
    }

    /**
     * @param webRootDir   directory produced by [SourceZipInspector.extract] (already
     *                     resolved to the real web root — see that class for why)
     * @param icon         decoded, already-square-able source icon bitmap
     * @param outputApk    where to write the unsigned APK
     * @param onEntry      progress callback, called per file copied (for the progress bar)
     * @param onLog        detailed step-by-step log lines for Step 4's build log panel
     */
    fun build(
        webRootDir: File,
        icon: Bitmap,
        appName: String,
        packageName: String,
        versionName: String,
        versionCode: Int,
        outputApk: File,
        onEntry: (Int, Int) -> Unit = { _, _ -> },
        onLog: (String) -> Unit = {}
    ) {
        val templateFile = materializeTemplate()
        onLog("Loaded shell template (${templateFile.length()} bytes)")

        val iconRenders = IconProcessor(context).renderAllDensities(icon) // density bucket -> PNG bytes
        onLog("Rendered launcher icon at ${iconRenders.size} densities")

        val webFiles = collectWebFiles(webRootDir)
        onLog("Collected ${webFiles.size} web files from ${webRootDir.name}")
        if (webFiles.isEmpty()) {
            throw BuildException("No files found under the resolved web root (${webRootDir.path}).")
        }

        ZipFile(templateFile).use { zip ->
            val entries = zip.entries().toList()
            val totalWork = entries.size + webFiles.size
            var done = 0
            var iconsReplaced = 0

            outputApk.parentFile?.mkdirs()
            ZipOutputStream(outputApk.outputStream().buffered()).use { zos ->
                val writtenNames = HashSet<String>()

                for (entry in entries) {
                    // Skip anything from the template we're about to fully replace.
                    if (entry.name.startsWith(WWW_PREFIX)) continue

                    val iconDensity = matchIconDensity(entry.name)
                    if (iconDensity != null) {
                        val png = iconRenders[iconDensity]
                        if (png != null) {
                            writeStoredOrDeflated(zos, entry.name, png)
                            writtenNames.add(entry.name)
                            iconsReplaced++
                            done++; onEntry(done, totalWork)
                            continue
                        }
                    }

                    if (entry.name == MANIFEST_ENTRY) {
                        val originalManifestBytes = zip.getInputStream(entry).readBytes()
                        val patched = try {
                            AxmlManifestPatcher.patch(
                                originalManifestBytes,
                                AxmlManifestPatcher.PatchRequest(
                                    newPackageName = packageName,
                                    newVersionName = versionName,
                                    newVersionCode = versionCode,
                                    newAppLabel = appName
                                )
                            )
                        } catch (e: AxmlManifestPatcher.UnsupportedManifestException) {
                            throw BuildException("Couldn't apply app identity to the manifest: ${e.message}", e)
                        }
                        onLog("Patched manifest: package=$packageName, versionName=$versionName, versionCode=$versionCode, label=\"$appName\"")
                        writeStoredOrDeflated(zos, MANIFEST_ENTRY, patched)
                        writtenNames.add(MANIFEST_ENTRY)
                    } else {
                        val bytes = zip.getInputStream(entry).readBytes()
                        writeStoredOrDeflated(zos, entry.name, bytes)
                        writtenNames.add(entry.name)
                    }
                    done++; onEntry(done, totalWork)
                }
                onLog("Replaced $iconsReplaced launcher icon entries")

                // Inject the user's web project under assets/www/
                var injected = 0
                for ((relativePath, file) in webFiles) {
                    val entryName = WWW_PREFIX + relativePath
                    if (entryName in writtenNames) continue
                    writeStoredOrDeflated(zos, entryName, file.readBytes())
                    injected++
                    done++; onEntry(done, totalWork)
                }
                onLog("Injected $injected files under assets/www/")
            }
        }
        onLog("Wrote unsigned APK: ${outputApk.name} (${outputApk.length()} bytes)")
    }

    /**
     * Matches a compiled-APK resource entry name against a launcher-icon density
     * bucket, e.g. "res/mipmap-xhdpi-v4/ic_launcher.png" -> "mipmap-xhdpi", or
     * "res/mipmap-hdpi/ic_launcher_round.png" -> "mipmap-hdpi". Returns null for
     * anything that isn't a launcher icon.
     */
    private fun matchIconDensity(entryName: String): String? {
        val m = ICON_ENTRY_REGEX.matchEntire(entryName) ?: return null
        return "mipmap-${m.groupValues[1]}"
    }

    private fun collectWebFiles(root: File): List<Pair<String, File>> {
        val out = ArrayList<Pair<String, File>>()
        fun walk(dir: File, prefix: String) {
            val children = dir.listFiles() ?: return
            for (child in children.sortedBy { it.name }) {
                val rel = if (prefix.isEmpty()) child.name else "$prefix/${child.name}"
                if (child.isDirectory) walk(child, rel) else out.add(rel to child)
            }
        }
        walk(root, "")
        return out
    }

    /** Writes an entry using STORED for already-compressed assets, DEFLATED otherwise — matches typical APK packing. */
    private fun writeStoredOrDeflated(zos: ZipOutputStream, name: String, bytes: ByteArray) {
        val entry = ZipEntry(name)
        entry.method = ZipEntry.DEFLATED
        zos.putNextEntry(entry)
        zos.write(bytes)
        zos.closeEntry()
    }

    /** Copies the bundled template asset into a real file, since ZipFile needs random file access (not a stream). */
    private fun materializeTemplate(): File {
        val out = File(context.cacheDir, "lia_shell_template.apk")
        try {
            context.assets.open(TEMPLATE_ASSET_PATH).use { input ->
                out.outputStream().use { output -> input.copyTo(output) }
            }
        } catch (e: java.io.FileNotFoundException) {
            throw TemplateMissingException(
                "Shell template APK is missing from assets/$TEMPLATE_ASSET_PATH. " +
                    "Build it from the companion LiaTools-ShellTemplate project and drop the output " +
                    "APK at that path before shipping Lia Tools."
            )
        }
        return out
    }
}
