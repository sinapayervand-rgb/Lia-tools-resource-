document.getElementById('btn').addEventListener('click', function () {
  document.getElementById('output').textContent = 'اپ داخل APK داره کار می‌کنه ✅';
});
